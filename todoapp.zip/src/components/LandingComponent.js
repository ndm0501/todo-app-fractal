import React from "react";
import Buckets from "./Buckets";

const LandingComponent = () => {
  return (
    <>
      <h1 className="my-4 text-center">Todos</h1>
      <Buckets />
    </>
  );
};
export default LandingComponent;
